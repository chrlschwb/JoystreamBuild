_joystream-node() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            "$1")
                cmd="joystream__node"
                ;;
            benchmark)
                cmd+="__benchmark"
                ;;
            block)
                cmd+="__block"
                ;;
            build-spec)
                cmd+="__build__spec"
                ;;
            chain-info)
                cmd+="__chain__info"
                ;;
            check-block)
                cmd+="__check__block"
                ;;
            export-blocks)
                cmd+="__export__blocks"
                ;;
            export-state)
                cmd+="__export__state"
                ;;
            extrinsic)
                cmd+="__extrinsic"
                ;;
            generate)
                cmd+="__generate"
                ;;
            generate-node-key)
                cmd+="__generate__node__key"
                ;;
            help)
                cmd+="__help"
                ;;
            import-blocks)
                cmd+="__import__blocks"
                ;;
            insert)
                cmd+="__insert"
                ;;
            inspect)
                cmd+="__inspect"
                ;;
            inspect-node-key)
                cmd+="__inspect__node__key"
                ;;
            key)
                cmd+="__key"
                ;;
            machine)
                cmd+="__machine"
                ;;
            overhead)
                cmd+="__overhead"
                ;;
            pallet)
                cmd+="__pallet"
                ;;
            purge-chain)
                cmd+="__purge__chain"
                ;;
            revert)
                cmd+="__revert"
                ;;
            sign)
                cmd+="__sign"
                ;;
            storage)
                cmd+="__storage"
                ;;
            vanity)
                cmd+="__vanity"
                ;;
            verify)
                cmd+="__verify"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        joystream__node)
            opts="-h -d -l --help --validator --no-grandpa --light --rpc-external --unsafe-rpc-external --rpc-methods --ws-external --unsafe-ws-external --rpc-max-payload --rpc-max-request-size --rpc-max-response-size --rpc-max-subscriptions-per-connection --prometheus-external --ipc-path --rpc-port --ws-port --ws-max-connections --ws-max-out-buffer-capacity --rpc-cors --prometheus-port --no-prometheus --name --no-telemetry --telemetry-url --offchain-worker --enable-offchain-indexing --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --bootnodes --reserved-nodes --reserved-only --public-addr --listen-addr --port --no-private-ipv4 --allow-private-ipv4 --out-peers --in-peers --in-peers-light --no-mdns --max-parallel-downloads --node-key --node-key-type --node-key-file --discover-local --kademlia-disjoint-query-paths --ipfs-server --sync --pool-limit --pool-kbytes --alice --bob --charlie --dave --eve --ferdie --one --two --force-authoring --keystore-uri --keystore-path --password-interactive --password --password-filename --max-runtime-instances --runtime-cache-size --tmp --no-hardware-benchmarks inspect benchmark key verify vanity sign build-spec check-block export-blocks export-state import-blocks purge-chain revert chain-info help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --rpc-methods)
                    COMPREPLY=($(compgen -W "auto safe unsafe" -- "${cur}"))
                    return 0
                    ;;
                --rpc-max-payload)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --rpc-max-request-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --rpc-max-response-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --rpc-max-subscriptions-per-connection)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ipc-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --rpc-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ws-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ws-max-connections)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ws-max-out-buffer-capacity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --rpc-cors)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --prometheus-port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --name)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --telemetry-url)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --offchain-worker)
                    COMPREPLY=($(compgen -W "always never when-validating" -- "${cur}"))
                    return 0
                    ;;
                --enable-offchain-indexing)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bootnodes)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --reserved-nodes)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --public-addr)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --listen-addr)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --port)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --out-peers)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --in-peers)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --in-peers-light)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --max-parallel-downloads)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --node-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --node-key-type)
                    COMPREPLY=($(compgen -W "ed25519" -- "${cur}"))
                    return 0
                    ;;
                --node-key-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --sync)
                    COMPREPLY=($(compgen -W "full fast fast-unsafe warp" -- "${cur}"))
                    return 0
                    ;;
                --pool-limit)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --pool-kbytes)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-uri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password-filename)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --max-runtime-instances)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --runtime-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark)
            opts="-h --help pallet storage overhead block machine help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__block)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --from --to --repeat --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --from)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --to)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --repeat)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__help)
            opts="<SUBCOMMAND>..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__machine)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --allow-fail --tolerance --verify-duration --hash-duration --memory-duration --disk-duration --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --tolerance)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --verify-duration)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --hash-duration)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --memory-duration)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --disk-duration)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__overhead)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --weight-path --metric --mul --add --warmup --repeat --max-ext-per-block --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --weight-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --metric)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mul)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --add)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --warmup)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --repeat)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --max-ext-per-block)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__pallet)
            opts="-p -e -s -r -d -l -h --pallet --extrinsic --steps --low --high --repeat --external-repeat --json --json-file --no-median-slopes --no-min-squares --output --header --template --output-analysis --heap-pages --no-verify --extra --record-proof --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --execution --wasm-execution --wasm-instantiation-strategy --db-cache --list --no-storage-info --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --pallet)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -p)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --extrinsic)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -e)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --steps)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -s)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --low)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --high)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --repeat)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -r)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --external-repeat)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --json-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --output)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --header)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --template)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --output-analysis)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --heap-pages)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasm-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__benchmark__storage)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --database --db-cache --pruning --keep-blocks --weight-path --metric --mul --add --skip-read --skip-write --template-path --json-read-path --json-write-path --warmups --state-version --state-cache-size --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --weight-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --metric)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mul)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --add)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --template-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --json-read-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --json-write-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --warmups)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --state-version)
                    COMPREPLY=($(compgen -W "0 1" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__build__spec)
            opts="-d -l -h --raw --disable-default-bootnode --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --node-key --node-key-type --node-key-file --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --node-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --node-key-type)
                    COMPREPLY=($(compgen -W "ed25519" -- "${cur}"))
                    return 0
                    ;;
                --node-key-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__chain__info)
            opts="-d -l -h --pruning --keep-blocks --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --database --db-cache --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__check__block)
            opts="-d -l -h --default-heap-pages --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --help <HASH or NUMBER>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --default-heap-pages)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__export__blocks)
            opts="-d -l -h --from --to --binary --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --help <OUTPUT>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --from)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --to)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__export__state)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --help <HASH or NUMBER>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__help)
            opts="<SUBCOMMAND>..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__import__blocks)
            opts="-d -l -h --default-heap-pages --binary --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --help <INPUT>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --default-heap-pages)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__inspect)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --database --db-cache --unsafe-pruning --wasm-execution --wasmtime-instantiation-strategy --wasm-runtime-overrides --execution-syncing --execution-import-block --execution-block-construction --execution-offchain-worker --execution-other --execution --state-cache-size --help block extrinsic help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --wasm-execution)
                    COMPREPLY=($(compgen -W "interpreted-i-know-what-i-do compiled" -- "${cur}"))
                    return 0
                    ;;
                --wasmtime-instantiation-strategy)
                    COMPREPLY=($(compgen -W "pooling-copy-on-write recreate-instance-copy-on-write pooling recreate-instance legacy-instance-reuse" -- "${cur}"))
                    return 0
                    ;;
                --wasm-runtime-overrides)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --execution-syncing)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-import-block)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-block-construction)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-offchain-worker)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution-other)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --execution)
                    COMPREPLY=($(compgen -W "native wasm both native-else-wasm" -- "${cur}"))
                    return 0
                    ;;
                --state-cache-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__inspect__block)
            opts="-h --help <HASH or NUMBER or BYTES>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__inspect__extrinsic)
            opts="-h --help <BLOCK:INDEX or BYTES>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__inspect__help)
            opts="<SUBCOMMAND>..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key)
            opts="-h --help generate-node-key generate inspect inspect-node-key insert help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__generate)
            opts="-w -n -h --words --keystore-uri --keystore-path --password-interactive --password --password-filename --network --output-type --scheme --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --words)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -w)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-uri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password-filename)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --network)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                -n)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                --output-type)
                    COMPREPLY=($(compgen -W "json text" -- "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__generate__node__key)
            opts="-h --file --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__help)
            opts="<SUBCOMMAND>..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__insert)
            opts="-d -l -h --suri --key-type --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --keystore-uri --keystore-path --password-interactive --password --password-filename --scheme --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --suri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --key-type)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --keystore-uri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password-filename)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__inspect)
            opts="-n -h --public --keystore-uri --keystore-path --password-interactive --password --password-filename --network --output-type --scheme --expect-public --help <URI>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --keystore-uri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password-filename)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --network)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                -n)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                --output-type)
                    COMPREPLY=($(compgen -W "json text" -- "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                --expect-public)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__key__inspect__node__key)
            opts="-n -h --file --network --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --network)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                -n)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__purge__chain)
            opts="-y -d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --database --db-cache --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --database)
                    COMPREPLY=($(compgen -W "rocksdb paritydb paritydb-experimental auto" -- "${cur}"))
                    return 0
                    ;;
                --db-cache)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__revert)
            opts="-d -l -h --chain --dev --base-path --log --detailed-log-output --disable-log-color --enable-log-reloading --tracing-targets --tracing-receiver --pruning --keep-blocks --help <NUM>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chain)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --base-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --log)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -l)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-targets)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --tracing-receiver)
                    COMPREPLY=($(compgen -W "log" -- "${cur}"))
                    return 0
                    ;;
                --pruning)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keep-blocks)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__sign)
            opts="-h --suri --message --hex --keystore-uri --keystore-path --password-interactive --password --password-filename --scheme --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --suri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --message)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-uri)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --keystore-path)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --password-filename)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__vanity)
            opts="-n -h --pattern --network --output-type --scheme --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --pattern)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --network)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                -n)
                    COMPREPLY=($(compgen -W "BareEd25519 BareSecp256k1 BareSr25519 DICO KICO acala ajuna altair apex ares astar aventus bajun basilisk bifrost calamari centrifuge cere cess cess-testnet chainx clover composable contextfree cord crust dark darwinia datahighway dentnet dock-pos-mainnet edgeware efinity equilibrium fragnova geek genshiro heiko hydradx integritee integritee-incognito interlay joystream jupiter kabocha kapex karura katalchain kilt kintsugi kulupu kusama laminar litentry litmus manta mathchain mathchain-testnet moonbeam moonriver neatcoin nftmart nodle oak origintrail-parachain parallel peaq phala picasso pioneer_network poli polkadex polkadexparachain polkadot polkafoundry polkasmith polymesh pontem-network quartz_mainnet reserved46 reserved47 reynolds robonomics shift social-network sora sora_kusama_para stafi subsocial subspace subspace_testnet substrate synesthesia tidefi tinker totem uniarts unique_mainnet vln xxnetwork zeitgeist zero zero-alphaville" -- "${cur}"))
                    return 0
                    ;;
                --output-type)
                    COMPREPLY=($(compgen -W "json text" -- "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        joystream__node__verify)
            opts="-h --message --hex --scheme --help <SIG> <URI>"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --message)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --scheme)
                    COMPREPLY=($(compgen -W "ed25519 sr25519 ecdsa" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

complete -F _joystream-node -o bashdefault -o default joystream-node
