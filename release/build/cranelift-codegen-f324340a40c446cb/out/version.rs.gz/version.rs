/// Version number of this crate. 
pub const VERSION: &str = "0.82.3";