
				pub const WASM_BINARY: Option<&[u8]> = Some(include_bytes!("/root/joystream/target/release/wbuild/joystream-node-runtime/joystream_node_runtime.compact.compressed.wasm"));
				pub const WASM_BINARY_BLOATY: Option<&[u8]> = Some(include_bytes!("/root/joystream/target/release/wbuild/joystream-node-runtime/joystream_node_runtime.wasm"));
			