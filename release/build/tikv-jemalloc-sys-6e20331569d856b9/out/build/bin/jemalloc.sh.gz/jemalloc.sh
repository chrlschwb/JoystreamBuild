#!/bin/sh

prefix=/root/joystream/target/release/build/tikv-jemalloc-sys-6e20331569d856b9/out
exec_prefix=/root/joystream/target/release/build/tikv-jemalloc-sys-6e20331569d856b9/out
libdir=${exec_prefix}/lib

LD_PRELOAD=${libdir}/libjemalloc.so.2
export LD_PRELOAD
exec "$@"
