#!/bin/sh

prefix=/root/joystream/target/release/build/tikv-jemalloc-sys-ad532d23b985d039/out
exec_prefix=/root/joystream/target/release/build/tikv-jemalloc-sys-ad532d23b985d039/out
libdir=${exec_prefix}/lib

LD_PRELOAD=${libdir}/libjemalloc.so.2
export LD_PRELOAD
exec "$@"
