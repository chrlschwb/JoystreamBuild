/// First we need to serialize the addresses in order to be able to sign them.
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuthorityRecord {
    /// Possibly multiple `MultiAddress`es through which the node can be 
    #[prost(bytes="vec", repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
}
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PeerSignature {
    #[prost(bytes="vec", tag="1")]
    pub signature: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="2")]
    pub public_key: ::prost::alloc::vec::Vec<u8>,
}
/// Then we need to serialize the authority record and signature to send them over the wire.
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignedAuthorityRecord {
    #[prost(bytes="vec", tag="1")]
    pub record: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="2")]
    pub auth_signature: ::prost::alloc::vec::Vec<u8>,
    /// Even if there are multiple `record.addresses`, all of them have the same peer id.
    /// Old versions are missing this field, so `optional` will provide compatibility both ways.
    #[prost(message, optional, tag="3")]
    pub peer_signature: ::core::option::Option<PeerSignature>,
}
