/// First we need to serialize the addresses in order to be able to sign them.
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuthorityAddresses {
    #[prost(bytes="vec", repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
}
/// Then we need to serialize addresses and signature to send them over the wire.
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignedAuthorityAddresses {
    #[prost(bytes="vec", tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="2")]
    pub signature: ::prost::alloc::vec::Vec<u8>,
}
